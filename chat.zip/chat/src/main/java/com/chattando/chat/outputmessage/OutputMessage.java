package com.chattando.chat.outputmessage;

public class OutputMessage {
	
	 private String content;

	    public OutputMessage() {
	    }

	    public OutputMessage(String content) {
	        this.content = content;
	    }

	    public String getContent() {
	        return content;
	    }
}
