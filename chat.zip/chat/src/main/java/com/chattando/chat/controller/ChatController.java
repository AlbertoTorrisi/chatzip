package com.chattando.chat.controller;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.util.HtmlUtils;

import com.chattando.chat.inputmessage.InputMessage;
import com.chattando.chat.outputmessage.OutputMessage;

@Controller
public class ChatController {


    @MessageMapping("/hello")
    @SendTo("/topic/greetings")
    public OutputMessage outputmessage(InputMessage message) throws Exception {
        Thread.sleep(1000); // simulated delay
        return new OutputMessage("# " + HtmlUtils.htmlEscape(message.getName()) + "!");
    }

}
