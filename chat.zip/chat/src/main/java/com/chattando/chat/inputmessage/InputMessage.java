package com.chattando.chat.inputmessage;

public class InputMessage {

	
	private String name;

    public InputMessage() {
    }

    public InputMessage(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
